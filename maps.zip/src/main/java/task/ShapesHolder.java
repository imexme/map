package task;

import javafx.scene.layout.AnchorPane;
import task.data.Category;
import task.data.Place;
import task.ui.shapes.PlaceShape;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Holds UI represntations of places
public class ShapesHolder {

    private final AnchorPane canvas;
    private List<PlaceShape> selected = new ArrayList<>();
    private Map<Category, List<PlaceShape>> byCategory = new HashMap<>();
    private Map<String, List<PlaceShape>> byName = new HashMap<>();
    private Places places = Places.getInstance();

    public ShapesHolder(List<Place> places, AnchorPane canvas) {
        this.canvas = canvas;
        places.forEach(this::append);
    }

    //draw shape and register in maps.
    public void append(Place place) {
        PlaceShape shape = place.getShape(this);
        register(byCategory, place.getCategory(), shape);
        register(byName, place.getName(), shape);
    }

    //Hide selected shapes and clear selected list
    public void hideSelected() {
        for (PlaceShape shape : selected) {
            shape.hide();
        }
        selected = new ArrayList<>();
    }

    public void hideCategory(Category category) {
        for (PlaceShape shape : byCategory.get(category)) {
            shape.hide();
        }
    }

    //Remove selected shapes and places and clear selected list
    public void removeSelected() {
        for (PlaceShape shape : selected) {
            shape.hide();
            places.remove(shape.getPlace());
        }
        selected = new ArrayList<>();
    }

    //callback to register selections
    public void handleSelection(PlaceShape placeShape) {
        if (!placeShape.isSelected())
            selected.remove(placeShape);
        else
            selected.add(placeShape);
    }

    //search and select
    public void search(String searchText) {
        List<PlaceShape> results = byName.get(searchText);
        if (!results.isEmpty())
            for (PlaceShape shape : results) {
                shape.select();
                handleSelection(shape);
            }
    }

    public AnchorPane getCanvas() {
        return canvas;
    }

    private <K> void register(Map<K, List<PlaceShape>> map, K key, PlaceShape value) {
        map.putIfAbsent(key, new ArrayList<>());
        map.get(key).add(value);
    }

}

