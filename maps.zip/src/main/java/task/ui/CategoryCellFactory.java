package task.ui;

import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import task.data.Category;


//to pretty category list view
public class CategoryCellFactory implements Callback<ListView<Category>, ListCell<Category>> {

    @Override
    public ListCell<Category> call(ListView<Category> list) {
        return new ListCell<Category>() {
            @Override
            protected void updateItem(Category item, boolean bln) {
                super.updateItem(item, bln);
                if (item != null) {
                    setText(new CategoryConverter().toString(item));
                }
            }
        };
    }
}