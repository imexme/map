package task.ui;

import task.data.Category;

//for pretty category combobox
public class CategoryConverter extends javafx.util.StringConverter<task.data.Category> {

    @Override
    public String toString(Category object) {
        return object.text();
    }

    @Override
    public Category fromString(String string) {
        return Category.parseCategory(string);
    }
}
