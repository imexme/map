package task.ui.dialogs;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.layout.GridPane;
import task.data.Place;
import task.data.Point;

import java.util.Optional;

import static javafx.scene.control.ButtonBar.ButtonData.OK_DONE;

public abstract class BaseDialog<T extends Place> {

    //dialog name/title placeholder
    public abstract String getTitle();

    //place placeholder
    protected abstract T getPlace(Point point);

    //content placeholder
    protected abstract Node getContent(GridPane grid);

    //main method to draw dialog, wait for result, and append place.
    public final T showDialog(Point point) {
        //append dialog
        Dialog<T> dialog = new Dialog<>();
        dialog.setTitle(getTitle());
        //append Save and Cancel buttons
        ButtonType saveButton = new ButtonType("Save", OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButton, ButtonType.CANCEL);
        //Create grid ad add it to dialog
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 10, 10, 10));
        dialog.getDialogPane().setContent(getContent(grid));

        //Add save button listener: get concrete place
        // do nothing if cancel
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButton) {
                return getPlace(point);
            }
            return null;
        });

        //wait for modal dialog result and append place when place comes.
        dialog.showAndWait();
        return dialog.getResult();
    }

}
