package task.ui.dialogs;

import javafx.util.StringConverter;

public class DialogsConverter extends StringConverter<BaseDialog> {

    @Override
    public String toString(BaseDialog object) {
        return object.getTitle();
    }

    @Override
    public BaseDialog fromString(String string) {
        return null;
    }
}
