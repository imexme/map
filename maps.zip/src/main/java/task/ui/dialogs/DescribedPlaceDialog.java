package task.ui.dialogs;

import javafx.scene.Node;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import task.data.Category;
import task.data.DescribedPlace;
import task.data.Point;
import task.ui.CategoryConverter;

import static javafx.collections.FXCollections.observableArrayList;

//Creates dialog which returns place of type: DescribedPlace
public class DescribedPlaceDialog extends BaseDialog<DescribedPlace> {

    private TextField name;
    private TextField description;
    private ChoiceBox<Category> category;

    //Returns DescribedPlace object
    @Override
    protected DescribedPlace getPlace(Point point) {
        return new DescribedPlace(name.getText(), point, category.getValue(), description.getText());
    }

    //Add inputs to append Place object: name
    @Override
    protected Node getContent(GridPane grid) {
        name = new TextField();
        description = new TextField();
        category = new ChoiceBox<>();
        category.setItems(observableArrayList(Category.values()));
        category.setConverter(new CategoryConverter());

        grid.add(new Label("Name:"), 0, 0);
        grid.add(name, 1, 0);
        grid.add(new Label("Description:"), 1, 1);
        grid.add(description, 1, 1);
        grid.add(new Label("Category:"), 0, 2);
        grid.add(category, 1, 2);
        return grid;
    }

    @Override
    public String getTitle() {
        return "Described";
    }

}
