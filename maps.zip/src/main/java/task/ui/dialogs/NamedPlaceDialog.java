package task.ui.dialogs;

import javafx.scene.Node;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import task.data.Category;
import task.data.NamedPlace;
import task.data.Point;
import task.ui.CategoryConverter;

import static javafx.collections.FXCollections.observableArrayList;

//Creates dialog which returns place of type: NamedPlace
public class NamedPlaceDialog extends BaseDialog<NamedPlace> {

    private TextField name;
    private ChoiceBox<Category> category;

    //Returns NamedPlace object
    @Override
    protected NamedPlace getPlace(Point point) {
        return new NamedPlace(name.getText(), point, category.getValue());
    }

    //Add inputs to append Place object: name
    @Override
    protected Node getContent(GridPane grid) {
        name = new TextField();
        category = new ChoiceBox<>();
        category.setItems(observableArrayList(Category.values()));
        category.setConverter(new CategoryConverter());

        grid.add(new Label("Name:"), 0, 0);
        grid.add(name, 1, 0);
        grid.add(new Label("Category:"), 0, 1);
        grid.add(category, 1, 1);
        return grid;
    }

    @Override
    public String getTitle() {
        return "Named";
    }

}
