package task.ui;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import task.Places;
import task.ShapesHolder;
import task.data.Category;
import task.data.Place;
import task.data.Point;
import task.ui.dialogs.BaseDialog;
import task.ui.dialogs.DescribedPlaceDialog;
import task.ui.dialogs.DialogsConverter;
import task.ui.dialogs.NamedPlaceDialog;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import static javafx.collections.FXCollections.observableArrayList;
import static task.ui.Alerts.confirmChanges;

//Java fx controller for maps.fxml
public class MapsController implements Initializable {

    public ImageView mapImg;
    public AnchorPane mapWrapper;
    public ComboBox<BaseDialog> type;
    public ListView<Category> categories;
    public TextField search;

    private Places places = Places.getInstance();
    private ShapesHolder placeShapes;

    private FileChooser mapChooser = new FileChooser();
    private FileChooser placesChooser = new FileChooser();

    //Initializes main window values
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeTypes();
        initializeCategories();
        mapChooser.setTitle("Open map");
        placesChooser.setTitle("Open places");
        mapImg.setOnMouseClicked(me -> {
            Place place = type.getValue().showDialog(new Point((int) me.getX(), (int) me.getY()));
            if (place != null) {
                places.create(place);
                placeShapes.append(place);
            }
        });
    }

    private void initializeCategories() {
        categories.setItems(observableArrayList(Category.values()));
        categories.setCellFactory(new CategoryCellFactory());
    }

    private void initializeTypes() {
        ObservableList<BaseDialog> dialogs = FXCollections.observableArrayList(
                new NamedPlaceDialog(),
                new DescribedPlaceDialog());
        type.setConverter(new DialogsConverter());
        type.setItems(dialogs);
        type.setValue(dialogs.get(0));
    }

    //Exit menu item action
    public void exit(ActionEvent event) {
        Platform.exit();
    }

    //Open map menu item action
    public void openMap(ActionEvent event) {
        File file = mapChooser.showOpenDialog(null);
        if (file != null) {
            String fileName = "file:" + file.getAbsolutePath();
            renderMap(fileName);
        }
    }

    //open places menu item action
    public void openPlaces(ActionEvent event) {
        File file = placesChooser.showOpenDialog(null);
        if (file != null) {
            renderPlaces(file);
        }
    }

    //Save places menu item action
    public void savePlaces(ActionEvent event) {
        places.save();
    }

    //Hide category button action
    public void hideCategory(ActionEvent event) {
        Category selectedItem = categories.getSelectionModel().getSelectedItem();
        placeShapes.hideCategory(selectedItem);

    }

    //Hide selected button action
    public void hideSelected(ActionEvent event) {
        placeShapes.hideSelected();
    }

    //Remove button action
    public void removeSelected(ActionEvent event) {
        placeShapes.removeSelected();
    }

    //Search button action
    public void doSearch(ActionEvent event) {
        if (!search.getText().isEmpty())
            placeShapes.search(search.getText());
    }

    private void renderMap(String fileName) {
        Image image = new Image(fileName);
        mapImg.setFitHeight(image.getHeight());
        mapImg.setFitWidth(image.getWidth());
        mapImg.setImage(image);
    }

    private void renderPlaces(File file) {
        if (places.isChanged()) confirmChanges();
        placeShapes = new ShapesHolder(places.load(file), mapWrapper);
    }

}
