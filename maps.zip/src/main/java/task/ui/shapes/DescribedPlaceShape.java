package task.ui.shapes;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import task.ShapesHolder;
import task.data.DescribedPlace;

//UI representation for Described place
public class DescribedPlaceShape extends PlaceShape<DescribedPlace> {

    public DescribedPlaceShape(DescribedPlace place, ShapesHolder holder) {
        super(place, holder);
    }

    protected Pane createDescriptionPane(DescribedPlace place) {
        Pane pane = new FlowPane();
        pane.setPrefWidth(100);
        pane.setLayoutX(place.getCoordinates().getX());
        pane.setLayoutY(place.getCoordinates().getY());
        pane.setStyle("-fx-background-color: white");
        Label label = new Label(place.getName());
        label.setPadding(new Insets(5, 5, 5, 5));
        pane.getChildren().add(label);
        Label labelDesc = new Label(place.getDescription());
        labelDesc.setPadding(new Insets(5, 5, 5, 5));
        pane.getChildren().add(labelDesc);
        return pane;
    }

}
