package task.ui.shapes;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import task.ShapesHolder;
import task.data.NamedPlace;

//UI representation for Named place
public class NamedPlaceShape extends PlaceShape<NamedPlace> {

    public NamedPlaceShape(NamedPlace place, ShapesHolder holder) {
        super(place, holder);
    }

    @Override
    protected Pane createDescriptionPane(NamedPlace place) {
        Pane pane = new AnchorPane();
        pane.setPrefWidth(100);
        pane.setLayoutX(place.getCoordinates().getX());
        pane.setLayoutY(place.getCoordinates().getY());
        pane.setStyle("-fx-background-color: white");
        Label label = new Label(place.getName());
        label.setPadding(new Insets(5, 5, 5, 5));
        pane.getChildren().add(label);
        return pane;
    }

}
