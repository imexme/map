package task.ui.shapes;

import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import task.ShapesHolder;
import task.data.Place;

import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

//abstract UI representation for places
//Render triangle. selection, fold/unfold (could be override)
public abstract class PlaceShape<T extends Place> {

    private static final int MARK_SIDE = 20;

    private T place;
    private AnchorPane canvas;
    private Polygon placeTriangle;
    private Rectangle selection;

    private Pane description;

    private boolean folded;
    private boolean selected;

    public PlaceShape(T place, ShapesHolder shapesHolder) {
        this.place = place;
        this.canvas = shapesHolder.getCanvas();
        placeTriangle = placeTriangle(shapesHolder);
        canvas.getChildren().add(placeTriangle);
    }

    public void hide() {
        placeTriangle.setVisible(false);
        unselect();
        unfold();
    }

    public T getPlace() {
        return place;
    }

    protected abstract Pane createDescriptionPane(T place);

    //draw upturned triangle
    private Polygon placeTriangle(ShapesHolder shapesHolder) {
        double x = place.getCoordinates().getX();
        double y = place.getCoordinates().getY();
        List<Double> points = new ArrayList<>();

        points.addAll(asList(x - MARK_SIDE / 2, y - MARK_SIDE));
        points.addAll(asList(x + MARK_SIDE / 2, y - MARK_SIDE));
        points.addAll(asList(x, y));

        Polygon polygon = new Polygon();
        polygon.setStroke(place.getCategory().getColor());
        polygon.setFill(place.getCategory().getColor());
        polygon.getPoints().addAll(points);

        polygon.setOnMouseClicked(me -> {
            if (me.getButton() == MouseButton.PRIMARY) {
                handleSelection();
                shapesHolder.handleSelection(this);
            } else if (me.getButton() == MouseButton.SECONDARY)
                handleFolding();
        });

        return polygon;
    }

    //toggle selection
    private void handleSelection() {
        if (selected) unselect();
        else select();
    }

    private void unselect() {
        selected = false;
        if (selection != null)
            selection.setVisible(false);
    }

    public void select() {
        if (selection == null) {
            selection = createSelection();
            canvas.getChildren().add(selection);
        }
        selected = true;
        selection.setVisible(true);
    }

    //draw rectangle over triangle
    private Rectangle createSelection() {
        Rectangle rect = new Rectangle();
        rect.setX(place.getCoordinates().getX() - MARK_SIDE / 2);
        rect.setY(place.getCoordinates().getY() - MARK_SIDE);
        rect.setHeight(MARK_SIDE);
        rect.setWidth(MARK_SIDE);
        rect.setFill(null);
        rect.setStroke(place.getCategory().getColor());
        return rect;
    }

    //toggle folding
    private void handleFolding() {
        if (folded) unfold();
        else fold();
    }

    private void unfold() {
        folded = false;
        if (description != null)
            description.setVisible(false);
    }

    private void fold() {
        if (description == null) {
            description = createDescriptionPane(place);
            canvas.getChildren().add(description);
        }
        folded = true;
        description.setVisible(true);
    }

    public boolean isSelected() {
        return selected;
    }
}
