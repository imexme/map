package task.ui;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import task.Places;

import java.util.Optional;

public class Alerts {

    //Check if places changed and as if yes (draw confirmation dialog)
    public static void confirmChanges() {
        if (Places.getInstance().isChanged()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("You have unsaved places");
            alert.setContentText("Save?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                Places.getInstance().save();
            }
        }
    }

}
