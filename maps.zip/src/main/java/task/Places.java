package task;

import task.data.Place;
import task.data.io.PlaceReader;
import task.data.io.PlaceWriter;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

//Places storage
public class Places {

    private static Places instance = new Places();
    private List<Place> places = new ArrayList<>();
    private boolean changed = false;
    private PlaceReader placeReader = new PlaceReader();
    private PlaceWriter placeWriter = new PlaceWriter();
    private File file;

    private Places() {
    }

    //Singleton (in case we can't use DI  this is the simplest way to share data storage)
    public static Places getInstance() {
        return instance;
    }

    //Load places form file using PlaceReader.
    public List<Place> load(File file) {
        this.file = file;
        try {
            return places = placeReader.read(new BufferedReader(new FileReader(file)));
        } catch (FileNotFoundException e) {
            throw new UncheckedIOException(e);
        }
    }

    //Write places to file using PlaceWriter.
    public void save() {
        if (changed)
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
                placeWriter.write(bw, places);
                changed = false;
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    public boolean isChanged() {
        return changed;
    }

    //add new place
    public void create(Place place) {
        changed = true;
        places.add(place);
    }

    //remove place
    public void remove(Place place) {
        changed = true;
        places.remove(place);
    }
}

