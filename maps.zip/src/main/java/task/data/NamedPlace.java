package task.data;

import task.ShapesHolder;
import task.ui.shapes.NamedPlaceShape;
import task.ui.shapes.PlaceShape;

public class NamedPlace extends Place {

    public NamedPlace(String name, Point coordinates, Category category) {
        super(name, coordinates, category);
    }

    @Override
    protected String type() {
        return "Named";
    }

    @Override
    public PlaceShape getShape(ShapesHolder holder) {
        return new NamedPlaceShape(this, holder);
    }
}
