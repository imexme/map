package task.data;

import task.ShapesHolder;
import task.ui.shapes.PlaceShape;

public abstract class Place {

    private String name;
    private Category category;
    private Point coordinates;

    public Place(String name, Point coordinates, Category category) {
        this.name = name;
        this.category = category;
        this.coordinates = coordinates;
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public Point getCoordinates() {
        return coordinates;
    }

    @Override
    public String toString() {
        return String.join(",", type(), category.text(), String.valueOf(coordinates.getX()), String.valueOf(coordinates.getY()), name);
    }

    //Place type
    protected abstract String type();

    //Place returns own UI representation
    public abstract PlaceShape getShape(ShapesHolder holder);

}
