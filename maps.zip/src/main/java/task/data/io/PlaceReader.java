package task.data.io;

import task.data.DescribedPlace;
import task.data.NamedPlace;
import task.data.Place;
import task.data.Point;

import java.io.BufferedReader;
import java.util.List;
import java.util.stream.Collectors;

import static task.data.Category.parseCategory;

public class PlaceReader {

    //Read places line by line
    public List<Place> read(BufferedReader reader) {
        return reader.lines()
                .map(this::parseLine)
                .collect(Collectors.toList());
    }

    private Place parseLine(String line) {
        String[] parts = line.split(",");
        switch (parts[0]) {
            case "Named":
                return new NamedPlace(parts[4], parseCoordinates(parts[2], parts[3]), parseCategory(parts[1]));
            case "Described":
                return new DescribedPlace(parts[4], parseCoordinates(parts[2], parts[3]), parseCategory(parts[1]), parts[5]);
            default:
                throw new IllegalArgumentException("Unknown type: " + parts[0]);
        }
    }

    private Point parseCoordinates(String x, String y) {
        return new Point(Integer.valueOf(x), Integer.valueOf(y));
    }
}
