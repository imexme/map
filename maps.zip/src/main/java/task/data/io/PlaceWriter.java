package task.data.io;

import task.data.Place;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;

public class PlaceWriter {

    //Write places line by line
    public void write(BufferedWriter writer, List<Place> places) throws IOException {
        for (Place place : places) {
            writer.write(place.toString());
            writer.newLine();
        }
    }
}
