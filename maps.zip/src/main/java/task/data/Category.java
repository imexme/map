package task.data;

import javafx.scene.paint.Color;

public enum Category {

    BUS(Color.RED, "Buss"),
    SUBWAY(Color.BLUE, "Tunnelbana"),
    TRAIN(Color.GREEN, "Tåg"),
    NONE(Color.BLACK, "None");

    private Color color;
    private String text;

    Category(Color color, String text) {
        this.color = color;
        this.text = text;
    }

    public static Category parseCategory(String category) {
        switch (category) {
            case "Buss":
                return BUS;
            case "Tunnelbana":
                return SUBWAY;
            case "Tåg":
                return TRAIN;
            case "None":
            default:
                return NONE;
        }
    }

    public String text() {
        return text;
    }

    public Color getColor() {
        return color;
    }
}
