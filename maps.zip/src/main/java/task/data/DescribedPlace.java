package task.data;

import task.ShapesHolder;
import task.ui.shapes.DescribedPlaceShape;
import task.ui.shapes.PlaceShape;

public class DescribedPlace extends Place {

    private String description;

    public DescribedPlace(String name, Point coordinates, Category category, String description) {
        super(name, coordinates, category);
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    protected String type() {
        return "Described";
    }

    @Override
    public PlaceShape getShape(ShapesHolder holder) {
        return new DescribedPlaceShape(this, holder);
    }

    @Override
    public String toString() {
        return super.toString() + "," + description;
    }
}
