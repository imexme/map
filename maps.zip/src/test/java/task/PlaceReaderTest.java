package task;

import org.junit.Test;
import task.data.Category;
import task.data.DescribedPlace;
import task.data.Place;
import task.data.io.PlaceReader;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class PlaceReaderTest {

    private PlaceReader testedInstance = new PlaceReader();

    @Test
    public void testParse() {
        String data = "Named,Buss,752,390,514\n" +
                "Named,None,731,403,nod\n" +
                "Described,Buss,423,291,514,DescribedName\n" +
                "Named,Tunnelbana,737,543,Kista\n" +
                "Named,Tåg,931,273,Helenelund";
        List<Place> parse = testedInstance.read(new BufferedReader(new StringReader(data)));

        assertThat(parse.size(), is(5));
    }

    @Test
    public void testParseSingleNamed() {
        Place place = testedInstance.read(new BufferedReader(new StringReader("Named,Tåg,931,273,Helenelund"))).get(0);

        assertThat(place.getCategory(), is(Category.TRAIN));
        assertThat(place.getName(), is("Helenelund"));
    }
    @Test
    public void testParseSingleDescribed() {
        DescribedPlace place = (DescribedPlace) testedInstance.read(new BufferedReader(new StringReader("Described,Tåg,931,273,Helenelund,DescribedName"))).get(0);

        assertThat(place.getCategory(), is(Category.TRAIN));
        assertThat(place.getName(), is("Helenelund"));
        assertThat(place.getDescription(), is("DescribedName"));
    }



}